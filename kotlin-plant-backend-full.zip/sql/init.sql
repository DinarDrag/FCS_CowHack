CREATE TABLE IF NOT EXISTS phase_info (
  id serial PRIMARY KEY,
  phase_key varchar(255) UNIQUE NOT NULL,
  title text,
  description text,
  advice text
);

INSERT INTO phase_info(phase_key, title, description, advice) VALUES
('seedling', 'Сеянец', 'Описание фазы - молодое растение', 'Уход: не поливать слишком часто'),
('vegetative', 'Вегетативная фаза', 'Растение активно растёт', 'Подкормка N-удобрениями'),
('flowering', 'Фаза цветения', 'Появляются цветы', 'Контроль влажности и вспрыскивание'),
('fruiting', 'Образование плодов', 'Плоды формируются', 'Поддерживать опыление')
ON CONFLICT DO NOTHING;
