# Kotlin Plant Backend (dev Docker setup)

Это готовый проект бэкенда на Kotlin + Spring Boot с mock ML-сервисом и Postgres, настроенный для разработки через Docker.

## Запуск (dev, с автоперезапуском через docker-compose)

Требования: Docker и Docker Compose.

1. Склонируйте или распакуйте проект.
2. Запустите:
   ```bash
   docker-compose up --build
   ```
   - Контейнер `app` использует образ `gradle:7.6-jdk17` и запускает `gradle bootRun`.
   - Исходники монтируются внутрь контейнера, поэтому после правок в коде достаточно перезапустить контейнер `app`:
     ```bash
     docker-compose restart app
     ```
3. API будет доступен: `http://localhost:8080/api/analyze`

## Тестирование
```bash
curl -X POST -F "image=@./test/photo.jpg" -F "overlay=true" http://localhost:8080/api/analyze
```

## Структура
- `src/main/kotlin/...` — Kotlin код
- `ml-mock/` — mock ML Flask сервис
- `sql/init.sql` — инициализация таблицы phase_info

## Примечания
- Для простоты в `docker-compose` используется образ `gradle`, который уже содержит Gradle.
- В проде рекомендуется собирать `jar` и запускать с `java -jar` в lean образе.
