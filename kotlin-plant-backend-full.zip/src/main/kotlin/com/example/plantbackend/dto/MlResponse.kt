package com.example.plantbackend.dto

data class MlResponse(
    val species: String = "",
    val phase: String = ""
)
