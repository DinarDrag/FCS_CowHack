package com.example.plantbackend

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.web.servlet.config.annotation.CorsRegistry
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer
import org.springframework.context.annotation.Bean
import org.springframework.beans.factory.annotation.Value

@SpringBootApplication
class PlantBackendApplication {
    @Bean
    fun corsConfigurer(@Value("\${cors.allowed-origins}") allowedOrigins: List<String>): WebMvcConfigurer {
        return object : WebMvcConfigurer {
            override fun addCorsMappings(registry: CorsRegistry) {
                registry.addMapping("/api/**")
                    .allowedOrigins(*allowedOrigins.toTypedArray())
                    .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
            }
        }
    }
}

fun main(args: Array<String>) {
    runApplication<PlantBackendApplication>(*args)
}
