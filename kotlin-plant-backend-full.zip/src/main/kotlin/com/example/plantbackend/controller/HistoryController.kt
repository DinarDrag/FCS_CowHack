package com.example.plantbackend.controller

import com.example.plantbackend.repository.RecognitionRecordRepository
import org.springframework.http.ResponseEntity
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/api/history")
class HistoryController(private val repo: RecognitionRecordRepository) {
    @GetMapping
    fun list() = ResponseEntity.ok(repo.findTop50ByOrderByCreatedAtDesc())
}
