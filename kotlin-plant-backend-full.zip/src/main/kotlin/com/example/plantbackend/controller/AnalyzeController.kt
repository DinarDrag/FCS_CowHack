package com.example.plantbackend.controller

import com.example.plantbackend.service.AnalyzeService
import org.springframework.http.ResponseEntity
import org.springframework.validation.annotation.Validated
import org.springframework.web.bind.annotation.*
import org.springframework.web.multipart.MultipartFile
import javax.validation.constraints.NotNull

@RestController
@RequestMapping("/api")
@Validated
class AnalyzeController(private val analyzeService: AnalyzeService) {

    data class AnalyzeResponse(
        val species: String,
        val phase: String,
        val phaseInfo: Any?,
        val imageBase64: String
    )

    @PostMapping("/analyze")
    fun analyze(@RequestParam("image") @NotNull image: MultipartFile,
                @RequestParam("overlay", required = false) overlay: Boolean?): ResponseEntity<AnalyzeResponse> {
        val res = analyzeService.analyze(image, overlay == true)

        return ResponseEntity.ok(
            AnalyzeResponse(
                species = res.species,
                phase = res.phase,
                phaseInfo = res.phaseInfo,
                imageBase64 = res.imageBase64
            )
        )
    }
}
