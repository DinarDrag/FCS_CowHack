package com.example.plantbackend.repository

import com.example.plantbackend.model.RecognitionRecord
import org.springframework.data.jpa.repository.JpaRepository

interface RecognitionRecordRepository : JpaRepository<RecognitionRecord, Long> {
    fun findTop50ByOrderByCreatedAtDesc(): List<RecognitionRecord>
}
