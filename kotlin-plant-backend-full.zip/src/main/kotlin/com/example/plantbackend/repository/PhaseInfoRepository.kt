package com.example.plantbackend.repository

import com.example.plantbackend.model.PhaseInfo
import org.springframework.data.jpa.repository.JpaRepository
import java.util.*

interface PhaseInfoRepository : JpaRepository<PhaseInfo, Long> {
    fun findByPhaseKey(phaseKey: String): Optional<PhaseInfo>
}
