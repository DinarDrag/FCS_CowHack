package com.example.plantbackend.service

import com.example.plantbackend.dto.MlResponse
import org.springframework.beans.factory.annotation.Value
import org.springframework.core.io.ByteArrayResource
import org.springframework.http.MediaType
import org.springframework.http.client.MultipartBodyBuilder
import org.springframework.stereotype.Component
import org.springframework.web.reactive.function.client.WebClient

@Component
class MlClient(@Value("\${ml.service.url}") private val mlUrl: String) {
    private val webClient = WebClient.create()

    fun predict(imageBytes: ByteArray): MlResponse {
        val builder = MultipartBodyBuilder()
        builder.part("image", ByteArrayResource(imageBytes)).header("Content-Disposition", "form-data; name=\"image\"; filename=\"upload.jpg\"")

        val response = webClient.post()
            .uri(mlUrl)
            .contentType(MediaType.MULTIPART_FORM_DATA)
            .bodyValue(builder.build())
            .retrieve()
            .bodyToMono(MlResponse::class.java)
            .block() ?: throw RuntimeException("ML service returned empty response")

        return response
    }
}
