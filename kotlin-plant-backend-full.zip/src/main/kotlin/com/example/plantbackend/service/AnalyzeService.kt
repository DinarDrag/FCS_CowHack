package com.example.plantbackend.service

import com.example.plantbackend.model.PhaseInfo
import com.example.plantbackend.model.RecognitionRecord
import com.example.plantbackend.repository.PhaseInfoRepository
import com.example.plantbackend.repository.RecognitionRecordRepository
import org.springframework.stereotype.Service
import org.apache.tomcat.util.codec.binary.Base64
import org.springframework.web.multipart.MultipartFile
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import javax.imageio.ImageIO
import java.awt.*
import java.awt.image.BufferedImage

@Service
class AnalyzeService(
    private val mlClient: MlClient,
    private val phaseInfoRepository: PhaseInfoRepository,
    private val recognitionRecordRepository: RecognitionRecordRepository
) {
    data class Result(
        val species: String,
        val phase: String,
        val phaseInfo: PhaseInfo?,
        val imageBase64: String
    )

    fun analyze(image: MultipartFile, overlay: Boolean = false): Result {
        val bytes = image.bytes
        val mlResp = mlClient.predict(bytes)

        val existing = phaseInfoRepository.findByPhaseKey(mlResp.phase)
        val phaseInfo = existing.orElse(null)

        val imageToReturnBytes = if (overlay) overlayTextOnImage(bytes, mlResp.species, mlResp.phase) else bytes
        val imageBase64 = Base64.encodeBase64String(imageToReturnBytes)

        // Save recognition record
        val record = RecognitionRecord(species = mlResp.species, phase = mlResp.phase, imageBase64 = imageBase64)
        recognitionRecordRepository.save(record)

        return Result(
            species = mlResp.species,
            phase = mlResp.phase,
            phaseInfo = phaseInfo,
            imageBase64 = imageBase64
        )
    }

    private fun overlayTextOnImage(bytes: ByteArray, species: String, phase: String): ByteArray {
        val input = ImageIO.read(ByteArrayInputStream(bytes)) ?: return bytes
        val g = input.createGraphics()
        g.font = Font("Arial", Font.BOLD, 28)
        g.composite = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.75f)
        val text = "${'$'}{species} — ${'$'}{phase}"
        val fm = g.fontMetrics
        val padding = 12
        val rectWidth = fm.stringWidth(text) + padding * 2
        val rectHeight = fm.height + padding * 2
        g.color = Color(0, 0, 0, 120)
        g.fillRect(10, input.height - rectHeight - 10, rectWidth, rectHeight)
        g.color = Color.WHITE
        g.drawString(text, 10 + padding, input.height - rectHeight - 10 + padding + fm.ascent)
        g.dispose()

        val baos = ByteArrayOutputStream()
        ImageIO.write(input, "jpg", baos)
        return baos.toByteArray()
    }
}
