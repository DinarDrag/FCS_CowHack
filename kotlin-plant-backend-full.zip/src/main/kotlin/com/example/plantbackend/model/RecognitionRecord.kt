package com.example.plantbackend.model

import java.time.Instant
import javax.persistence.*

@Entity
@Table(name = "recognition_record")
data class RecognitionRecord(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,

    val species: String = "",
    val phase: String = "",

    @Column(columnDefinition = "text")
    val imageBase64: String = "",

    val createdAt: Instant = Instant.now()
)
