package com.example.plantbackend.model

import javax.persistence.*

@Entity
@Table(name = "phase_info")
data class PhaseInfo(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long = 0,

    @Column(nullable = false, unique = true)
    val phaseKey: String = "",

    @Column(columnDefinition = "text")
    val title: String = "",

    @Column(columnDefinition = "text")
    val description: String = "",

    @Column(columnDefinition = "text")
    val advice: String = ""
)
