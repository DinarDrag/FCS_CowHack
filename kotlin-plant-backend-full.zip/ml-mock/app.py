from flask import Flask, request, jsonify
from PIL import Image
import io

app = Flask(__name__)

@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return jsonify({'error': 'no image'}), 400
    file = request.files['image']
    try:
        img = Image.open(file.stream)
    except Exception as e:
        return jsonify({'error': 'invalid image'}), 400
    w, h = img.size
    if w < 300:
        phase = 'seedling'
    elif w < 800:
        phase = 'vegetative'
    else:
        phase = 'flowering'
    return jsonify({'species': 'Mockus plantus', 'phase': phase})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
